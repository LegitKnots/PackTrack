import express from 'express';
import admin from 'firebase-admin';
import auth from '../middleware/auth'; // Your auth middleware

const router = express.Router();

// GET /api/packs - get packs for current user
router.get('/', auth, async (req, res) => {
  try {
    const userId = req.user.uid;

    const snapshot = await admin.firestore()
      .collection('packs')
      .where('members', 'array-contains', userId)
      .get();

    const packs = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
    res.json(packs);
  } catch (err) {
    console.error('Error fetching packs:', err);
    res.status(500).json({ message: 'Failed to fetch packs' });
  }
});

export default router;
