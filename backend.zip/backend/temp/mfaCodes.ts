// Just temporary in-memory store for MFA codes
const mfaCodes = {};
module.exports = mfaCodes;
