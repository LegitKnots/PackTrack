export const SERVER_URI = "http://10.0.1.16:3001";
export const GOOGLE_MAPS_APIKEY = "AIzaSyALOLeklnmLqvYB3Sn4n_TQeHLn2pr71Ts";
export const PRIMARY_APP_COLOR = "#f3631a"